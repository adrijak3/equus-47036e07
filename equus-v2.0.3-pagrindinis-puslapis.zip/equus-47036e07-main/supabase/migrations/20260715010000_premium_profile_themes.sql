-- Equus v2.0.2.1: premium temos

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS theme text;

UPDATE public.profiles
SET theme = CASE theme
  WHEN 'blue' THEN 'ocean'
  WHEN 'dark' THEN 'midnight'
  WHEN 'light' THEN 'pearl'
  ELSE COALESCE(theme, 'ocean')
END;

ALTER TABLE public.profiles
ALTER COLUMN theme SET DEFAULT 'ocean';

ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_theme_check;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_theme_check
CHECK (theme IN ('ocean', 'midnight', 'pearl', 'stable'));
