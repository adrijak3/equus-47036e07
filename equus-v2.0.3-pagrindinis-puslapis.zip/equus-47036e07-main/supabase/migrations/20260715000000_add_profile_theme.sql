-- Equus v2.0.2: vartotojo pasirinktos temos išsaugojimas paskyroje

ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS theme text;

UPDATE public.profiles
SET theme = 'blue'
WHERE theme IS NULL;

ALTER TABLE public.profiles
ALTER COLUMN theme SET DEFAULT 'blue';

ALTER TABLE public.profiles
DROP CONSTRAINT IF EXISTS profiles_theme_check;

ALTER TABLE public.profiles
ADD CONSTRAINT profiles_theme_check
CHECK (theme IN ('blue', 'dark', 'light'));
