import React, { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { calculateSubPriceByType, dbDayOfWeek, expiryFromPurchase, formatDateISO, formatTime, LESSON_TYPE_LABEL, MONTHS_LT_NOM, WEEKDAYS_LT, type LessonType } from "@/lib/equus";
import { CalendarDays, Clock, CheckCircle2, XCircle, Plus, MessageSquare, Star, Trash2, Settings, KeyRound, User as UserIcon, Wallet, Inbox, Mail, Phone, Save, ShieldCheck, BadgeCheck, Palette, Moon, Sun, Sparkles, Eye, EyeOff } from "lucide-react";
import { Horse } from "@/components/icons/Horse";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";
import { FloralAccent } from "@/components/Decorations";
import { VacationsPanel, VacationBanner } from "@/components/VacationsPanel";
import { useEquusTheme, type EquusTheme } from "@/contexts/ThemeContext";

interface Booking {
  id: string;
  slot_date: string;
  slot_time: string;
  status: string;
  counts_in_subscription: boolean;
  subscription_id?: string | null;
  horse_name?: string | null;
}
interface Subscription {
  id: string;
  lessons_total: number;
  lessons_used: number;
  sickness_credits: number;
  price: number;
  purchase_date: string;
  expires_at: string;
  paid: boolean;
  lesson_type?: string;
}
interface PermanentSlot {
  id: string;
  day_of_week: number;
  slot_time: string;
}
interface PendingSickReq {
  id: string;
  booking_id: string;
  document_url: string | null;
  document_deadline: string | null;
  slot_date?: string;
  slot_time?: string;
}
interface AvailableSlot {
  id: string;
  day_of_week: number;
  slot_time: string;
}

export default function Paskyra() {
  const { user, profile, refreshProfile, activeProfileId, activeProfileName, linkedProfiles } = useAuth();
  const acting = activeProfileId ?? user?.id ?? null;
  const isLinked = !!user && acting !== user.id;
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [messages, setMessages] = useState<{ id: string; body: string; created_at: string; read_by_admin: boolean; from_admin: boolean; parent_id: string | null; read_by_user: boolean }[]>([]);
  const [permanents, setPermanents] = useState<PermanentSlot[]>([]);
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([]);
  const [sickReqs, setSickReqs] = useState<PendingSickReq[]>([]);
  const [loading, setLoading] = useState(true);

  // Add subscription dialog
  const [subDialog, setSubDialog] = useState(false);
  const [newSubLessons, setNewSubLessons] = useState(8);
  const [newSubDate, setNewSubDate] = useState(formatDateISO(new Date()));
  const [newSubPaid, setNewSubPaid] = useState(false);
  const [newSubType, setNewSubType] = useState<LessonType>("sportine");
  const [newSubAlreadyUsed, setNewSubAlreadyUsed] = useState(0);
  /** Past bookings without a subscription (offered to attribute when buying) */
  const [unattributedPast, setUnattributedPast] = useState<Booking[]>([]);
  const [attributeIds, setAttributeIds] = useState<Set<string>>(new Set());



  // Message
  const [msgBody, setMsgBody] = useState("");
  const [sending, setSending] = useState(false);

  const load = async () => {
    if (!user || !acting) return;
    setLoading(true);
    // Auto-process past lessons (Vilnius TZ) so subscription counters are fresh
    try { await supabase.functions.invoke("process-lessons"); } catch { /* non-fatal */ }
    const [b, s, m, p, ts] = await Promise.all([
      supabase.from("bookings").select("*").eq("user_id", acting).order("slot_date").order("slot_time"),
      supabase.from("subscriptions").select("*").eq("user_id", acting).order("purchase_date", { ascending: false }),
      supabase.from("messages").select("*").eq("user_id", user.id).order("created_at", { ascending: true }).limit(200),
      supabase.from("permanent_slots").select("*").eq("user_id", acting).order("day_of_week").order("slot_time"),
      supabase.from("time_slots").select("id, day_of_week, slot_time").eq("active", true).order("day_of_week").order("slot_time"),
    ]);
    // attach horse names from horse_assignments
    const bs = (b.data ?? []) as any[];
    if (bs.length) {
      const ids = bs.map((x) => x.id);
      const { data: ha } = await supabase
        .from("horse_assignments")
        .select("booking_id, horse_id, slot_date, slot_time")
        .in("booking_id", ids);
      const horseIds = Array.from(new Set((ha ?? []).map((x: any) => x.horse_id)));
      let horseMap: Record<string, string> = {};
      if (horseIds.length) {
        const { data: hs } = await supabase.from("horses").select("id, name").in("id", horseIds);
        horseMap = Object.fromEntries((hs ?? []).map((h: any) => [h.id, h.name]));
      }
      const haMap: Record<string, string> = {};
      (ha ?? []).forEach((x: any) => { if (x.booking_id) haMap[x.booking_id] = horseMap[x.horse_id]; });
      setBookings(bs.map((x) => ({ ...x, horse_name: haMap[x.id] ?? null })));
    } else {
      setBookings([]);
    }
    setSubs(s.data ?? []);
    setMessages(m.data ?? []);
    setPermanents(p.data ?? []);
    setAvailableSlots(ts.data ?? []);

    // Load pending sickness cancellations awaiting / with documents
    const { data: sr } = await supabase
      .from("cancellation_requests")
      .select("id, booking_id, document_url, document_deadline, status, sickness, bookings(slot_date, slot_time)")
      .eq("user_id", acting)
      .eq("sickness", true)
      .order("created_at", { ascending: false })
      .limit(20);
    setSickReqs((sr ?? []).map((r: any) => ({
      id: r.id, booking_id: r.booking_id,
      document_url: r.document_url, document_deadline: r.document_deadline,
      slot_date: r.bookings?.slot_date, slot_time: r.bookings?.slot_time,
    })));

    setLoading(false);
  };
  const markSickDocSubmitted = async (req: PendingSickReq, sentinel: string) => {
    const { error } = await supabase.from("cancellation_requests")
      .update({ document_url: sentinel, document_uploaded_at: new Date().toISOString() })
      .eq("id", req.id);
    if (error) { toast.error(error.message); return false; }
    return true;
  };

  const sendSickDocViaMessage = async (req: PendingSickReq) => {
    if (!user) return;
    const body = `[Ligos pažyma] Pamoka ${req.slot_date} ${req.slot_time?.slice(0,5)} — pažymą atsiųsiu žinute (prikabinsiu nuotrauką arba PDF).`;
    const { error } = await supabase.from("messages").insert({ user_id: user.id, body });
    if (error) { toast.error(error.message); return; }
    if (await markSickDocSubmitted(req, "SENT_VIA_MESSAGE")) {
      toast.success("Pranešta administracijai — prisekite failą žinučių skiltyje");
      load();
    }
  };

  const sendSickDocViaEmail = async (req: PendingSickReq) => {
    const adminEmail = "jojimomokykla@gmail.com";
    const subject = encodeURIComponent(`Ligos pažyma — ${req.slot_date} ${req.slot_time?.slice(0,5)}`);
    const bodyTxt = encodeURIComponent(`Sveiki,\n\nSiunčiu ligos pažymą už pamoką ${req.slot_date} ${req.slot_time?.slice(0,5)}.\n\nAčiū.`);
    window.open(`mailto:${adminEmail}?subject=${subject}&body=${bodyTxt}`, "_blank");
    if (await markSickDocSubmitted(req, "SENT_VIA_EMAIL")) {
      toast.success("Pažymėta — neužmirškite išsiųsti laiško");
      load();
    }
  };


  // Mark received admin replies as read once user opens the page
  useEffect(() => {
    if (!user) return;
    const unread = messages.filter((m) => m.from_admin && !m.read_by_user).map((m) => m.id);
    if (unread.length > 0) {
      supabase.from("messages").update({ read_by_user: true }).in("id", unread);
    }
  }, [messages, user]);

  useEffect(() => { load(); }, [user, acting]);

  const now = new Date();
  const future = bookings.filter((b) => b.status === "active" && new Date(`${b.slot_date}T${b.slot_time}`) >= now);
  const past = bookings.filter((b) => new Date(`${b.slot_date}T${b.slot_time}`) < now);

  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const monthBookings = past.filter((b) => {
    const d = new Date(`${b.slot_date}T${b.slot_time}`);
    return d >= monthStart && d < monthEnd;
  });
  const monthAttended = monthBookings.filter((b) => b.status === "active" || b.status === "completed");

  // Lifetime stats
  const totalAttended = past.filter(
    (b) => (b.status === "active" || b.status === "completed") && b.counts_in_subscription === true,
  ).length;
  const totalCancelled = bookings.filter((b) => b.status === "cancelled").length;

  const effLessons = newSubType === "vienkartine" ? 1 : newSubLessons;
  const newSubPrice = calculateSubPriceByType(effLessons, newSubType);

  // When subscription dialog opens, pre-load past bookings that aren't tied to any subscription.
  useEffect(() => {
    if (!subDialog || !acting) return;
    (async () => {
      // Include today's bookings too — admin/user chooses whether today counts
      const { data } = await supabase
        .from("bookings")
        .select("id, slot_date, slot_time, status, counts_in_subscription, subscription_id")
        .eq("user_id", acting)
        .is("subscription_id", null)
        .lte("slot_date", formatDateISO(new Date()))
        .neq("status", "cancelled")
        .gte("slot_date", newSubDate)
        .order("slot_date", { ascending: false })
        .limit(30);
      setUnattributedPast((data ?? []) as any);
      setAttributeIds(new Set());
    })();
  }, [subDialog, acting, newSubDate]);

  const addSubscription = async () => {
    if (!user || !acting) return;
    if (effLessons < 1 || effLessons > 50) { toast.error("Pamokų skaičius 1–50"); return; }
    const fromAttribution = attributeIds.size;
    const totalUsed = newSubAlreadyUsed + fromAttribution;
    if (totalUsed > effLessons) {
      toast.error(`Panaudota (${totalUsed}) negali viršyti pamokų sk. (${effLessons})`);
      return;
    }
    const { data: ins, error } = await supabase.from("subscriptions").insert({
      user_id: acting,
      lessons_total: effLessons,
      lessons_used: totalUsed,
      lesson_type: newSubType,
      price: newSubPrice,
      purchase_date: newSubDate,
      expires_at: expiryFromPurchase(newSubDate),
      paid: newSubPaid,
    } as any).select("id").maybeSingle();
    if (error) { toast.error(error.message); return; }
    // Attribute selected past bookings to this new subscription
    if (ins?.id && attributeIds.size > 0) {
      await supabase.from("bookings")
        .update({ subscription_id: ins.id, counts_in_subscription: true } as any)
        .in("id", Array.from(attributeIds));
    }
    toast.success("Abonementas pridėtas");
    setSubDialog(false);
    setNewSubLessons(8);
    setNewSubPaid(false);
    setNewSubType("sportine");
    setNewSubAlreadyUsed(0);
    setAttributeIds(new Set());
    load();
  };

  const sendMessage = async () => {
    if (!user || msgBody.trim().length < 1) return;
    setSending(true);
    const { error } = await supabase.from("messages").insert({ user_id: user.id, body: msgBody.trim() });
    setSending(false);
    if (error) { toast.error(error.message); return; }
    setMsgBody("");
    toast.success("Žinutė išsiųsta");
    load();
  };

  // Permanent slots — users can only view & remove (admin adds them)

  const removePermanent = async (id: string) => {
    const slot = permanents.find((p) => p.id === id);
    if (!slot) return;
    if (!confirm("Pašalinti nuolatinį laiką? Visos jūsų būsimos pamokos šiuo laiku bus atšauktos.")) return;
    const { error } = await supabase.from("permanent_slots").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    // Cancel all future active bookings for this user that fall on this weekday + time
    const todayISO = formatDateISO(new Date());
    const { data: future } = await supabase
      .from("bookings")
      .select("id, slot_date")
      .eq("user_id", acting!)
      .eq("slot_time", slot.slot_time)
      .gte("slot_date", todayISO)
      .eq("status", "active");
    const ids = (future ?? [])
      .filter((b) => dbDayOfWeek(new Date(`${b.slot_date}T00:00:00`)) === slot.day_of_week)
      .map((b) => b.id);
    if (ids.length > 0) {
      await supabase.from("bookings").update({ status: "cancelled" }).in("id", ids);
    }
    toast.success("Pašalinta. Būsimos pamokos atšauktos.");
    load();
  };

  const markSubPaid = async (subId: string) => {
    if (!confirm("Pažymėti šį abonementą kaip APMOKĖTĄ?")) return;
    const { error } = await supabase.from("subscriptions").update({ paid: true }).eq("id", subId);
    if (error) { toast.error(error.message); return; }
    toast.success("Pažymėta apmokėta. Administracija patvirtins.");
    load();
  };

  const deleteSub = async (subId: string) => {
    if (!confirm("Ar tikrai norite ištrinti šį abonementą? Šio veiksmo atšaukti negalėsite.")) return;
    const { error } = await supabase.from("subscriptions").delete().eq("id", subId);
    if (error) { toast.error(error.message); return; }
    toast.success("Abonementas ištrintas");
    load();
  };

  const editSubLessons = async (s: Subscription) => {
    const txt = prompt(
      `Pakeisti treniruočių skaičių abonemente.\n\nDabar: ${s.lessons_used}/${s.lessons_total}\nGalima padidinti arba sumažinti. Jei sumažinsite mažiau už panaudotų, panaudotų skaičius bus automatiškai sumažintas.`,
      String(s.lessons_total),
    );
    if (txt === null) return;
    const n = parseInt(txt);
    if (!Number.isFinite(n) || n < 1 || n > 100) { toast.error("Įveskite skaičių 1–100"); return; }
    const newUsed = Math.min(s.lessons_used, n);
    const { error } = await supabase.from("subscriptions")
      .update({ lessons_total: n, lessons_used: newUsed }).eq("id", s.id);
    if (error) { toast.error(error.message); return; }
    toast.success("Atnaujinta");
    load();
  };

  const monthLabel = MONTHS_LT_NOM[now.getMonth()];

  return (
    <div className="container max-w-4xl py-8 sm:py-14 relative">
      <FloralAccent className="absolute -top-4 -right-12 hidden md:block" size={140} delay={0.3} rotate={25} />

      <motion.header
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="mb-8"
      >
        <p className="text-xs uppercase tracking-[0.25em] text-gold/70 mb-2">Sveiki sugrįžę</p>
        <h1 className="text-4xl sm:text-5xl font-display text-gradient-gold">{activeProfileName || profile?.full_name || "—"}</h1>
        {isLinked && (
          <p className="text-xs text-blush/80 mt-1 italic">
            Aktyvus profilis: {activeProfileName} · perjungti meniu
          </p>
        )}
        <div className="gold-divider mt-4 max-w-[120px]" />
      </motion.header>

      <VacationBanner userId={acting} />

      <Tabs defaultValue="lessons">
        <TabsList className="grid grid-cols-5 w-full bg-background/50 mb-6 h-auto gap-1 p-1">
          <TabsTrigger value="lessons" aria-label="Treniruotės" title="Treniruotės" className="py-2">
            <Horse size={18} />
          </TabsTrigger>
          <TabsTrigger value="subs" aria-label="Abonementai" title="Abonementai" className="py-2">
            <Wallet className="w-[18px] h-[18px]" />
          </TabsTrigger>
          <TabsTrigger value="permanent" aria-label="Nuolatiniai" title="Nuolatiniai laikai" className="py-2">
            <Star className="w-[18px] h-[18px]" />
          </TabsTrigger>
          <TabsTrigger value="messages" aria-label="Žinutės" title="Žinutės" className="py-2">
            <Inbox className="w-[18px] h-[18px]" />
          </TabsTrigger>
          <TabsTrigger value="settings" aria-label="Nuostatos" title="Nuostatos" className="py-2">
            <Settings className="w-[18px] h-[18px]" />
          </TabsTrigger>
        </TabsList>

        {/* LESSONS */}
        <TabsContent value="lessons" className="space-y-6">
          {sickReqs.filter((r) => !r.document_url && r.document_deadline).length > 0 && (
            <Section title="Ligos pažymos" icon={<XCircle className="w-4 h-4" />}>
              <ul className="divide-y divide-gold/5">
                {sickReqs.filter((r) => !r.document_url && r.document_deadline).map((r) => {
                  const overdue = r.document_deadline && r.document_deadline < formatDateISO(new Date());
                  return (
                    <li key={r.id} className="px-5 py-3 text-sm flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-medium">
                          Pamoka {r.slot_date} {r.slot_time?.slice(0, 5)}
                        </div>
                        <div className={cn("text-xs", overdue ? "text-destructive" : "text-muted-foreground")}>
                          {overdue
                            ? "Terminas pasibaigęs — laukia administracijos sprendimo"
                            : `Įkelti pažymą iki: ${r.document_deadline}`}
                        </div>
                      </div>
                      {!overdue && (
                        <div className="flex flex-wrap gap-2">
                          <Button size="sm" variant="gold" onClick={() => sendSickDocViaMessage(r)}>
                            <MessageSquare className="w-4 h-4" /> Žinute administracijai
                          </Button>
                          <Button size="sm" variant="outlineGold" onClick={() => sendSickDocViaEmail(r)}>
                            El. paštu
                          </Button>
                        </div>
                      )}
                    </li>
                  );
                })}
              </ul>
            </Section>
          )}

          {/* Lifetime stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-card border border-gold/15 rounded-lg p-5 text-center shadow-elegant">
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Iš viso treniruočių</div>
              <div className="font-display text-4xl text-gradient-gold tabular-nums mt-1">{totalAttended}</div>
            </div>
            <div className="bg-gradient-card border border-gold/15 rounded-lg p-5 text-center shadow-elegant">
              <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Atšauktų</div>
              <div className="font-display text-4xl text-blush tabular-nums mt-1">{totalCancelled}</div>
            </div>
          </div>

          <Section title="Užsirašytos treniruotės" icon={<CalendarDays className="w-4 h-4" />}>
            {future.length === 0 ? (
              <Empty text="Nėra suplanuotų treniruočių" />
            ) : (
              <ul className="divide-y divide-gold/5">
                {future.map((b) => <BookingRow key={b.id} b={b} />)}
              </ul>
            )}
          </Section>

          <Section title={`${monthLabel} lankomumas`} icon={<CheckCircle2 className="w-4 h-4" />}>
            <div className="flex items-baseline gap-3 px-5 py-3">
              <span className="font-display text-4xl text-gradient-gold tabular-nums">{monthAttended.length}</span>
              <span className="text-sm text-muted-foreground">treniruočių šį mėnesį</span>
            </div>
            {monthBookings.length > 0 && (
              <ul className="divide-y divide-gold/5 border-t border-gold/10">
                {monthBookings.map((b) => <BookingRow key={b.id} b={b} past />)}
              </ul>
            )}
          </Section>

          {(() => {
            const pastAttended = past.filter((b) => b.status === "active" || b.status === "completed");
            const pastCancelled = bookings.filter((b) => b.status === "cancelled");
            return (
              <>
                <Section title="Įvykusios treniruotės" icon={<CheckCircle2 className="w-4 h-4" />}>
                  {pastAttended.length === 0 ? (
                    <Empty text="Dar nebuvo įvykusių treniruočių" />
                  ) : (
                    <ul className="divide-y divide-gold/5 max-h-96 overflow-auto">
                      {pastAttended.slice().reverse().map((b) => <BookingRow key={b.id} b={b} past />)}
                    </ul>
                  )}
                </Section>

                <Section title="Atšauktos treniruotės" icon={<XCircle className="w-4 h-4" />}>
                  {pastCancelled.length === 0 ? (
                    <Empty text="Atšauktų treniruočių nėra" />
                  ) : (
                    <ul className="divide-y divide-gold/5 max-h-96 overflow-auto">
                      {pastCancelled.slice().reverse().map((b) => <BookingRow key={b.id} b={b} past />)}
                    </ul>
                  )}
                </Section>
              </>
            );
          })()}
        </TabsContent>

        {/* SUBSCRIPTIONS */}
        <TabsContent value="subs" className="space-y-4">
          <div className="flex justify-end">
            <Button variant="gold" onClick={() => setSubDialog(true)}>
              <Plus className="w-4 h-4" /> Pridėti abonementą
            </Button>
          </div>
          {subs.length === 0 ? (
            <Empty text="Nėra abonementų" />
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {subs.map((s) => {
                const attributedUsed = bookings.filter((b) =>
                  b.subscription_id === s.id &&
                  b.status !== "cancelled" &&
                  b.counts_in_subscription !== false,
                ).length;
                // Honor manually-entered "already used" baseline stored in lessons_used
                const actualUsed = Math.max(attributedUsed, s.lessons_used ?? 0);
                const remaining = s.lessons_total - actualUsed;
                const expDays = Math.ceil((new Date(s.expires_at).getTime() - Date.now()) / 86400000);
                const lowRemaining = remaining <= 1 || (expDays <= 7 && expDays >= 0);
                return (
                  <div key={s.id} className="relative">
                    {lowRemaining && (
                      <div className="absolute -top-2 left-3 z-10 px-2 py-0.5 rounded-full bg-destructive/80 text-destructive-foreground text-[10px] uppercase tracking-wider font-semibold animate-pulse">
                        {remaining <= 1 ? "Liko ≤1 treniruotė" : `Baigiasi po ${expDays} d.`}
                      </div>
                    )}
                    <SubscriptionCard s={s} effectiveUsed={actualUsed} onMarkPaid={markSubPaid} onDelete={undefined} onEditLessons={undefined} />
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* MESSAGES */}
        <TabsContent value="messages" className="space-y-4">
          <div className="bg-gradient-card border border-gold/15 rounded-lg p-5">
            <Label htmlFor="msg" className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-4 h-4 text-gold" /> Žinutė administracijai
            </Label>
            <Textarea
              id="msg"
              value={msgBody}
              onChange={(e) => setMsgBody(e.target.value)}
              maxLength={2000}
              rows={4}
              placeholder="Rašykite čia..."
            />
            <div className="flex justify-end mt-3">
              <Button variant="gold" disabled={sending || !msgBody.trim()} onClick={sendMessage}>
                Siųsti
              </Button>
            </div>
          </div>
          {messages.length > 0 && (
            <Section title="Pokalbis su administracija">
              <p className="px-5 pt-3 text-[11px] text-muted-foreground italic">
                Pokalbiai automatiškai ištrinami po 3 dienų nuo paskutinės žinutės.
              </p>
              <ul className="divide-y divide-gold/5 max-h-[500px] overflow-auto mt-2">
                {messages.map((m) => (
                  <li
                    key={m.id}
                    className={cn(
                      "px-5 py-3",
                      m.from_admin && "bg-gold/5",
                    )}
                  >
                    <div className="flex items-baseline justify-between gap-2 mb-1">
                      <span className={cn("text-xs uppercase tracking-wide", m.from_admin ? "text-gold" : "text-muted-foreground")}>
                        {m.from_admin ? "✦ Administracija" : "Jūs"}
                      </span>
                      <span className="text-xs text-muted-foreground">{new Date(m.created_at).toLocaleString("lt-LT")}</span>
                    </div>
                    <div className="text-sm whitespace-pre-wrap">{m.body}</div>
                    {!m.from_admin && (
                      <div className="text-[11px] text-muted-foreground mt-1">
                        {m.read_by_admin ? "✓ Perskaityta" : "Išsiųsta"}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </Section>
          )}
        </TabsContent>

        {/* PERMANENT SLOTS */}
        <TabsContent value="permanent" className="space-y-4">
          <PermanentSlotsSection
            permanents={permanents}
            onRemove={removePermanent}
          />
        </TabsContent>

        {/* SETTINGS */}
        <TabsContent value="settings" className="space-y-6">
          <ProfileSettings onSaved={refreshProfile} />
          <PasswordChange />
          <AppearanceSettings />
          <Section title="Mano atostogos" icon={<CalendarDays className="w-4 h-4" />}>
            <VacationsPanel userId={acting} />
          </Section>
        </TabsContent>
      </Tabs>

      {/* Add subscription dialog */}
      <Dialog open={subDialog} onOpenChange={setSubDialog}>
        <DialogContent className="bg-gradient-card border-gold/20">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-gradient-gold">Naujas abonementas</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="sub-date">Pirkimo data</Label>
              <Input id="sub-date" type="date" value={newSubDate} onChange={(e) => setNewSubDate(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="sub-type">Tipas</Label>
              <select id="sub-type" value={newSubType} onChange={(e) => setNewSubType(e.target.value as LessonType)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                <option value="sportine">Sportinė</option>
                <option value="nesportine">Nesportinė</option>
                <option value="vienkartine">Vienkartinė (1 pamoka)</option>
              </select>
            </div>
            {newSubType !== "vienkartine" && (
            <div>
              <Label htmlFor="sub-lessons">Pamokų skaičius</Label>
              <Input id="sub-lessons" type="number" min={1} max={50} value={newSubLessons}
                onChange={(e) => setNewSubLessons(parseInt(e.target.value) || 0)} />
              <p className="text-xs text-muted-foreground mt-1.5">
                Galioja 30 dienų
              </p>
            </div>
            )}
            <div>
              <Label htmlFor="sub-used">Jau panaudota treniruočių</Label>
              <Input
                id="sub-used"
                type="number"
                min={0}
                max={effLessons}
                value={newSubAlreadyUsed}
                onChange={(e) => setNewSubAlreadyUsed(Math.max(0, parseInt(e.target.value) || 0))}
              />
              <p className="text-xs text-muted-foreground mt-1.5">
                Jeigu šio abonemento jau buvote panaudoję — įrašykite kiek. Naujam abonementui palikite 0.
              </p>
            </div>
            {unattributedPast.length > 0 && (
              <div className="border border-gold/15 rounded-md p-3 bg-background/30">
                <Label className="text-xs uppercase tracking-wider text-muted-foreground">
                  Įtraukti į šį abonementą (nuo pirkimo dienos)
                </Label>
                <p className="text-[11px] text-muted-foreground mt-1 mb-2">
                  Pažymėkite jau įvykusias treniruotes (įsk. šiandienos), kurios turėtų skaičiuotis šiame abonemente.
                </p>
                <ul className="space-y-1 max-h-44 overflow-auto">
                  {unattributedPast.map((b) => {
                    const checked = attributeIds.has(b.id);
                    const isToday = b.slot_date === formatDateISO(new Date());
                    return (
                      <li key={b.id}>
                        <label className="flex items-center gap-2 text-sm cursor-pointer rounded px-2 py-1 hover:bg-gold/5">
                          <input
                            type="checkbox"
                            className="accent-gold"
                            checked={checked}
                            onChange={(e) => {
                              setAttributeIds((prev) => {
                                const next = new Set(prev);
                                if (e.target.checked) next.add(b.id);
                                else next.delete(b.id);
                                return next;
                              });
                            }}
                          />
                          <span className="tabular-nums">{b.slot_date} · {formatTime(b.slot_time)}</span>
                          {isToday && <span className="text-[10px] uppercase tracking-wider text-gold">šiandien</span>}
                        </label>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
            <div className="flex items-baseline justify-between p-4 rounded-md bg-gold/5 border border-gold/15">
              <span className="text-sm">Iš viso</span>
              <span className="text-3xl font-display text-gradient-gold tabular-nums">{newSubPrice} €</span>
            </div>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="checkbox" checked={newSubPaid} onChange={(e) => setNewSubPaid(e.target.checked)} className="accent-gold" />
              Jau apmokėta
            </label>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSubDialog(false)}>Atšaukti</Button>
            <Button variant="gold" onClick={addSubscription}>Pridėti</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ───────────── Settings sub-sections ───────────── */

function splitFullName(fullName: string) {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  return {
    firstName: parts[0] ?? "",
    lastName: parts.slice(1).join(" "),
  };
}

function ProfileSettings({ onSaved }: { onSaved: () => void | Promise<void> }) {
  const { user, profile, isAdmin, isTrainer } = useAuth();
  const initial = splitFullName(profile?.full_name ?? "");
  const [firstName, setFirstName] = useState(initial.firstName);
  const [lastName, setLastName] = useState(initial.lastName);
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const [displayName, setDisplayName] = useState(profile?.display_name ?? "");
  const [email, setEmail] = useState(user?.email ?? "");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const next = splitFullName(profile?.full_name ?? "");
    setFirstName(next.firstName);
    setLastName(next.lastName);
    setPhone(profile?.phone ?? "");
    setDisplayName(profile?.display_name ?? "");
  }, [profile]);

  useEffect(() => {
    setEmail(user?.email ?? "");
  }, [user?.email]);

  const fullName = `${firstName.trim()} ${lastName.trim()}`.trim();
  const previewName = displayName.trim() || fullName || "Jūsų vardas";
  const initials = [firstName, lastName]
    .map((value) => value.trim().charAt(0).toUpperCase())
    .filter(Boolean)
    .join("")
    .slice(0, 2) || "EQ";

  const roleLabel = isAdmin ? "Administratorė" : isTrainer ? "Trenerė" : "Raitelė";

  const save = async () => {
    if (!user) return;
    if (firstName.trim().length < 2) { toast.error("Įveskite vardą"); return; }
    if (lastName.trim().length < 2) { toast.error("Įveskite pavardę"); return; }
    if (phone.trim() && !/^\+?[0-9 ()-]{7,20}$/.test(phone.trim())) {
      toast.error("Patikrinkite telefono numerį");
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) {
      toast.error("Patikrinkite el. pašto adresą");
      return;
    }

    setSaving(true);
    const { error: profileError } = await supabase.from("profiles")
      .update({
        full_name: fullName,
        phone: phone.trim() || null,
        display_name: displayName.trim() || null,
      })
      .eq("id", user.id);

    if (profileError) {
      setSaving(false);
      toast.error(profileError.message);
      return;
    }

    const currentEmail = user.email ?? "";
    if (email.trim().toLowerCase() !== currentEmail.toLowerCase()) {
      const { error: emailError } = await supabase.auth.updateUser({ email: email.trim() });
      if (emailError) {
        setSaving(false);
        toast.error(`Profilis išsaugotas, bet el. pašto pakeisti nepavyko: ${emailError.message}`);
        await onSaved();
        return;
      }
      toast.success("Pakeitimai išsaugoti. Patvirtinkite naują el. paštą gautame laiške.");
    } else {
      toast.success("Paskyros informacija išsaugota");
    }

    setSaving(false);
    await onSaved();
  };

  return (
    <div className="space-y-6">
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="overflow-hidden rounded-2xl border border-gold/15 bg-gradient-card shadow-elegant"
      >
        <div className="relative overflow-hidden border-b border-gold/10 px-5 py-6 sm:px-7">
          <div className="pointer-events-none absolute -right-12 -top-16 h-44 w-44 rounded-full bg-gold/[0.08] blur-3xl" />
          <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center">
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-gold/25 bg-gold/10 font-display text-2xl text-gold shadow-gold">
              {initials}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-gold/65">Paskyros profilis</p>
              <h2 className="mt-1 truncate font-display text-2xl text-foreground sm:text-3xl">{fullName || "Jūsų profilis"}</h2>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1 rounded-full border border-gold/15 bg-gold/5 px-2.5 py-1 text-gold/85">
                  <BadgeCheck className="h-3.5 w-3.5" /> {roleLabel}
                </span>
                <span>Grafike rodoma: <strong className="font-medium text-foreground/85">{previewName}</strong></span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-7 p-5 sm:p-7">
          <div>
            <div className="mb-4 flex items-center gap-2">
              <UserIcon className="h-4 w-4 text-gold" />
              <h3 className="font-display text-lg text-foreground">Asmeninė informacija</h3>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="pf-first-name">Vardas</Label>
                <Input id="pf-first-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} maxLength={40} autoComplete="given-name" />
              </div>
              <div>
                <Label htmlFor="pf-last-name">Pavardė</Label>
                <Input id="pf-last-name" value={lastName} onChange={(e) => setLastName(e.target.value)} maxLength={60} autoComplete="family-name" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="pf-display">Vardas, rodomas grafike</Label>
                <Input
                  id="pf-display"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  maxLength={40}
                  placeholder={fullName || "Pvz. Adrija K."}
                />
                <div className="mt-2 flex items-center gap-2 rounded-lg border border-gold/10 bg-background/35 px-3 py-2 text-xs text-muted-foreground">
                  <Eye className="h-3.5 w-3.5 text-gold/70" />
                  Peržiūra: <span className="font-medium text-foreground/85">{previewName}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gold/10 pt-6">
            <div className="mb-4 flex items-center gap-2">
              <Phone className="h-4 w-4 text-gold" />
              <h3 className="font-display text-lg text-foreground">Kontaktinė informacija</h3>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="pf-phone">Telefono numeris</Label>
                <Input id="pf-phone" value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={20} autoComplete="tel" placeholder="+370 6..." />
                <p className="mt-1.5 text-[11px] text-muted-foreground">Naudojamas susisiekti ir slaptažodžiui atkurti.</p>
              </div>
              <div>
                <Label htmlFor="pf-email">El. paštas</Label>
                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="pf-email" className="pl-9" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
                </div>
                <p className="mt-1.5 text-[11px] text-muted-foreground">Pakeitus el. paštą gali reikėti jį patvirtinti.</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 border-t border-gold/10 pt-6 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-xs text-muted-foreground">Pakeitimai pritaikomi jūsų paskyrai ir tvarkaraščiui.</p>
            <Button variant="gold" onClick={save} disabled={saving} className="min-w-[180px]">
              {saving ? "Saugoma…" : <><Save className="mr-1.5 h-4 w-4" /> Išsaugoti pakeitimus</>}
            </Button>
          </div>
        </div>
      </motion.section>

      <Section title="Paskyros informacija" icon={<ShieldCheck className="w-4 h-4" />}>
        <div className="grid gap-3 p-5 sm:grid-cols-3">
          <AccountInfo label="Rolė" value={roleLabel} />
          <AccountInfo
            label="Registracijos data"
            value={profile?.created_at ? new Date(profile.created_at).toLocaleDateString("lt-LT") : "—"}
          />
          <AccountInfo label="Paskyros ID" value={user?.id ? `${user.id.slice(0, 8)}…` : "—"} mono />
        </div>
      </Section>
    </div>
  );
}

function AccountInfo({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="rounded-xl border border-gold/10 bg-background/35 px-4 py-3">
      <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{label}</div>
      <div className={cn("mt-1 text-sm font-medium text-foreground/90", mono && "font-mono")}>{value}</div>
    </div>
  );
}

function PermanentSlotsSection({
  permanents,
  onRemove,
}: {
  permanents: PermanentSlot[];
  onRemove: (id: string) => void;
}) {
  return (
    <Section title="Nuolatiniai laikai" icon={<Star className="w-4 h-4" />}>
      <div className="p-5">
        <p className="text-sm text-muted-foreground mb-4">
          Nuolatiniai laikai – tai jūsų savaitiniai treniruočių laikai, į kuriuos esate automatiškai užregistruojama kiekvieną savaitę.
        </p>
        {permanents.length === 0 ? (
          <p className="text-sm italic text-muted-foreground py-3">Šiuo metu neturite nuolatinių laikų</p>
        ) : (
          <ul className="space-y-2">
            {permanents.map((p) => (
              <li key={p.id} className="flex items-center justify-between bg-gold/5 border border-gold/15 rounded-md px-4 py-2.5">
                <span className="flex items-center gap-2">
                  <Star className="w-3.5 h-3.5 fill-gold text-gold" />
                  <span className="font-medium">{WEEKDAYS_LT[p.day_of_week - 1]}</span>
                  <span className="text-muted-foreground tabular-nums">{formatTime(p.slot_time)}</span>
                </span>
                <button
                  onClick={() => onRemove(p.id)}
                  className="text-muted-foreground hover:text-destructive transition-colors"
                  aria-label="Pašalinti"
                  title="Pašalinti nuolatinį laiką"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Section>
  );
}

function PasswordChange() {
  const { user, profile } = useAuth();
  const [phone, setPhone] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!user?.email) return;
    if (pw.length < 8) { toast.error("Slaptažodis turi būti bent 8 simbolių"); return; }
    if (pw !== pw2) { toast.error("Slaptažodžiai nesutampa"); return; }
    if (!phone.trim()) { toast.error("Įveskite telefono numerį"); return; }
    setBusy(true);
    const { data, error } = await supabase.functions.invoke("reset-password-by-phone", {
      body: { email: user.email, phone: phone.trim(), new_password: pw },
    });
    setBusy(false);
    if (error || (data as any)?.error) {
      toast.error((data as any)?.error || error?.message || "Klaida");
      return;
    }
    toast.success("Slaptažodis sėkmingai pakeistas");
    setPhone(""); setPw(""); setPw2("");
  };

  return (
    <Section title="Saugumas" icon={<KeyRound className="w-4 h-4" />}>
      <div className="p-5 sm:p-7">
        <div className="mb-5 flex items-start gap-3 rounded-xl border border-gold/10 bg-gold/[0.04] p-4">
          <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-gold" />
          <div>
            <div className="text-sm font-medium text-foreground">Pakeisti slaptažodį</div>
            <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
              Patvirtinimui įveskite paskyroje nurodytą telefono numerį
              {profile?.phone ? <> — <span className="text-foreground/80">{profile.phone}</span></> : "."}
            </p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Label htmlFor="pc-phone">Telefonas patvirtinimui</Label>
            <Input id="pc-phone" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" placeholder="+370 6..." />
          </div>
          <div>
            <Label htmlFor="pc-pw">Naujas slaptažodis</Label>
            <div className="relative">
              <Input id="pc-pw" type={showPassword ? "text" : "password"} value={pw} onChange={(e) => setPw(e.target.value)} minLength={8} autoComplete="new-password" />
              <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "Slėpti slaptažodį" : "Rodyti slaptažodį"}>
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <div>
            <Label htmlFor="pc-pw2">Pakartokite slaptažodį</Label>
            <Input id="pc-pw2" type={showPassword ? "text" : "password"} value={pw2} onChange={(e) => setPw2(e.target.value)} minLength={8} autoComplete="new-password" />
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <Button variant="outlineGold" onClick={submit} disabled={busy}>
            {busy ? "Keičiama…" : <><KeyRound className="mr-1.5 h-4 w-4" /> Pakeisti slaptažodį</>}
          </Button>
        </div>
      </div>
    </Section>
  );
}

function AppearanceSettings() {
  const { theme, setTheme } = useEquusTheme();
  const options: Array<{ value: EquusTheme; label: string; description: string; icon: React.ReactNode }> = [
    { value: "ocean", label: "Equus mėlyna", description: "Pagrindinė jojimo mokyklos tema", icon: <Sparkles className="h-5 w-5" /> },
    { value: "midnight", label: "Tamsi", description: "Neutrali tamsi išvaizda", icon: <Moon className="h-5 w-5" /> },
    { value: "pearl", label: "Šviesi", description: "Švari šviesi išvaizda", icon: <Sun className="h-5 w-5" /> },
  ];

  return (
    <Section title="Išvaizda" icon={<Palette className="w-4 h-4" />}>
      <div className="grid gap-3 p-5 sm:grid-cols-3">
        {options.map((option) => {
          const selected = theme === option.value;
          return (
            <button
              key={option.value}
              type="button"
              onClick={() => setTheme(option.value)}
              className={cn(
                "rounded-xl border p-4 text-left transition-all",
                selected
                  ? "border-gold/55 bg-gold/10 shadow-gold"
                  : "border-gold/10 bg-background/35 hover:border-gold/30 hover:bg-gold/[0.04]",
              )}
            >
              <div className="flex items-center justify-between gap-3">
                <span className={selected ? "text-gold" : "text-muted-foreground"}>{option.icon}</span>
                <span className={cn("h-3 w-3 rounded-full border", selected ? "border-gold bg-gold" : "border-muted-foreground/40")} />
              </div>
              <div className="mt-4 text-sm font-medium text-foreground">{option.label}</div>
              <div className="mt-1 text-xs leading-relaxed text-muted-foreground">{option.description}</div>
            </button>
          );
        })}
      </div>
    </Section>
  );
}

/* ───────────── Shared bits ───────────── */

function Section({ title, icon, children }: { title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className="bg-gradient-card border border-gold/15 rounded-lg overflow-hidden shadow-elegant"
    >
      <h2 className="px-5 py-3 border-b border-gold/10 font-display text-lg text-gold flex items-center gap-2">
        {icon} {title}
      </h2>
      {children}
    </motion.section>
  );
}

function Empty({ text }: { text: string }) {
  return <p className="px-5 py-8 text-center text-sm text-muted-foreground italic">{text}</p>;
}

function BookingRow({ b, past }: { b: Booking; past?: boolean }) {
  const d = new Date(`${b.slot_date}T${b.slot_time}`);
  return (
    <li className="flex items-center justify-between px-5 py-3 text-sm">
      <div>
        <div className="font-medium">
          {d.toLocaleDateString("lt-LT", { weekday: "long", day: "numeric", month: "long" })}
        </div>
        <div className="text-muted-foreground tabular-nums">
          {formatTime(b.slot_time)}
          {b.horse_name && (
            <span className="ml-2 text-xs text-gold/80 font-mono">({b.horse_name})</span>
          )}
        </div>
      </div>
      <div>
        {b.status === "cancelled" && <span className="text-xs px-2 py-0.5 rounded bg-destructive/15 text-destructive">Atšaukta</span>}
        {past && (b.status === "completed" || b.status === "active") && (
          <span className="text-xs text-gold/80">
            ✓ {b.counts_in_subscription === false ? "Įvyko (nesiskaičiuoja)" : "Įvyko"}
          </span>
        )}
      </div>
    </li>
  );
}

export function SubscriptionCard({ s, effectiveUsed, onMarkPaid, onDelete, onEditLessons, extra }: { s: Subscription; effectiveUsed?: number; onMarkPaid?: (id: string) => void; onDelete?: (id: string) => void; onEditLessons?: (s: Subscription) => void; extra?: React.ReactNode }) {
  const used = effectiveUsed ?? s.lessons_used;
  const remaining = s.lessons_total - used;
  const expired = new Date(s.expires_at) < new Date();
  const empty = remaining <= 0;
  return (
    <div className={cn(
      "p-5 rounded-lg border bg-gradient-card transition-all",
      empty ? "border-destructive/40 shadow-[0_0_30px_-8px_hsl(var(--destructive)/0.3)]" : "border-gold/15",
      expired && "opacity-60",
    )}>
      <div className="flex items-baseline justify-between mb-3">
        {onEditLessons ? (
          <button
            type="button"
            onClick={() => onEditLessons(s)}
            className="text-3xl font-display text-gradient-gold tabular-nums hover:opacity-80 transition-opacity"
            title="Pakeisti treniruočių skaičių"
          >
            {used}/{s.lessons_total}
          </button>
        ) : (
          <span className="text-3xl font-display text-gradient-gold tabular-nums">
            {used}/{s.lessons_total}
          </span>
        )}
        {s.paid ? (
          <span className="text-xs px-2 py-0.5 rounded-full bg-gold/15 text-gold border border-gold/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Apmokėta
          </span>
        ) : (
          <button
            type="button"
            onClick={() => onMarkPaid?.(s.id)}
            className="text-xs px-2 py-0.5 rounded-full bg-blush/15 text-blush border border-blush/30 flex items-center gap-1 hover:bg-blush/25 transition-colors cursor-pointer"
            title="Spauskite, kad pažymėtumėte kaip apmokėtą"
          >
            <XCircle className="w-3 h-3" /> Neapmokėta · pažymėti
          </button>
        )}
      </div>
      <div className="text-sm space-y-1 text-muted-foreground">
        {s.lesson_type && (
          <div>Tipas: <span className="text-foreground">{LESSON_TYPE_LABEL[(s.lesson_type as LessonType)] ?? s.lesson_type}</span></div>
        )}
        <div>Pirkta: <span className="text-foreground">{s.purchase_date}</span></div>
        <div>Galioja iki: <span className={cn("text-foreground", expired && "text-destructive")}>{s.expires_at}</span></div>
        <div>Suma: <span className="text-foreground tabular-nums">{Number(s.price).toFixed(2)} €</span></div>
        {(s.sickness_credits ?? 0) > 0 && (
          <div className="text-blush">+{s.sickness_credits} (liga)</div>
        )}
      </div>
      {empty && !expired && (
        <p className="mt-3 text-xs text-destructive font-medium">Pamokos baigėsi — pridėkite naują abonementą</p>
      )}
      {extra && (
        <div className="mt-3 pt-3 border-t border-gold/10">{extra}</div>
      )}
      {onDelete && (
        <div className="mt-4 pt-3 border-t border-gold/10 flex justify-end">
          <button
            type="button"
            onClick={() => onDelete(s.id)}
            className="text-xs text-muted-foreground hover:text-destructive transition-colors inline-flex items-center gap-1"
            title="Ištrinti šį abonementą"
          >
            <Trash2 className="w-3 h-3" /> Ištrinti
          </button>
        </div>
      )}
    </div>
  );
}

