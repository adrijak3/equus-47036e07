import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type EquusTheme = "ocean" | "midnight" | "pearl" | "stable";

interface ThemeContextValue {
  theme: EquusTheme;
  setTheme: (theme: EquusTheme) => void;
  saving: boolean;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

const STORAGE_KEY = "equus_theme";
const THEMES: EquusTheme[] = ["ocean", "midnight", "pearl", "stable"];

const isTheme = (value: unknown): value is EquusTheme =>
  typeof value === "string" && THEMES.includes(value as EquusTheme);

const readStoredTheme = (): EquusTheme => {
  if (typeof window === "undefined") return "blue";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "blue") return "ocean";
  if (stored === "dark") return "midnight";
  if (stored === "light") return "pearl";
  return isTheme(stored) ? stored : "ocean";
};

const applyTheme = (theme: EquusTheme) => {
  const root = document.documentElement;
  root.dataset.theme = theme;
  root.classList.toggle("dark", theme !== "pearl");
  root.style.colorScheme = theme === "pearl" ? "light" : "dark";
};

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<EquusTheme>(readStoredTheme);
  const [saving, setSaving] = useState(false);
  const userIdRef = useRef<string | null>(null);
  const hydratedUserRef = useRef<string | null>(null);

  const saveThemeToProfile = useCallback(async (nextTheme: EquusTheme) => {
    const userId = userIdRef.current;
    if (!userId) return;

    setSaving(true);
    const { error } = await supabase
      .from("profiles")
      .update({ theme: nextTheme })
      .eq("id", userId);
    setSaving(false);

    if (error) {
      // Vietinis pasirinkimas vis tiek lieka išsaugotas.
      console.warn("Nepavyko išsaugoti temos paskyroje:", error.message);
    }
  }, []);

  const setTheme = useCallback((nextTheme: EquusTheme) => {
    setThemeState(nextTheme);
    applyTheme(nextTheme);
    window.localStorage.setItem(STORAGE_KEY, nextTheme);
    void saveThemeToProfile(nextTheme);
  }, [saveThemeToProfile]);

  useEffect(() => {
    applyTheme(theme);
    window.localStorage.setItem(STORAGE_KEY, theme);
  }, [theme]);

  useEffect(() => {
    let active = true;

    const hydrateForUser = async (userId: string | null) => {
      userIdRef.current = userId;

      if (!userId) {
        hydratedUserRef.current = null;
        return;
      }

      if (hydratedUserRef.current === userId) return;
      hydratedUserRef.current = userId;

      const { data, error } = await supabase
        .from("profiles")
        .select("theme")
        .eq("id", userId)
        .maybeSingle();

      if (!active || error) return;

      const remoteTheme = data?.theme;
      if (isTheme(remoteTheme)) {
        setThemeState(remoteTheme);
        applyTheme(remoteTheme);
        window.localStorage.setItem(STORAGE_KEY, remoteTheme);
      } else {
        // Senesnėms paskyroms pirmą kartą įrašome vietinį pasirinkimą.
        await supabase
          .from("profiles")
          .update({ theme })
          .eq("id", userId);
      }
    };

    supabase.auth.getUser().then(({ data }) => {
      void hydrateForUser(data.user?.id ?? null);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      void hydrateForUser(session?.user?.id ?? null);
    });

    return () => {
      active = false;
      listener.subscription.unsubscribe();
    };
  }, [theme]);

  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key !== STORAGE_KEY || !isTheme(event.newValue)) return;
      setThemeState(event.newValue);
      applyTheme(event.newValue);
    };

    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, saving }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useEquusTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useEquusTheme turi būti naudojamas ThemeProvider viduje");
  }
  return context;
}
